﻿namespace tp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Init = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Btn_Quit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Txt_Op1 = new System.Windows.Forms.TextBox();
            this.Txt_Op2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Btn_Add = new System.Windows.Forms.Button();
            this.Btn_Sous = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.Btn_Div = new System.Windows.Forms.Button();
            this.Btn_Mod = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Txt_Exp = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Txt_Res = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Btn_Mul = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_Init
            // 
            this.Btn_Init.Location = new System.Drawing.Point(381, 328);
            this.Btn_Init.Name = "Btn_Init";
            this.Btn_Init.Size = new System.Drawing.Size(88, 23);
            this.Btn_Init.TabIndex = 0;
            this.Btn_Init.Text = "inisialiser";
            this.Btn_Init.UseVisualStyleBackColor = true;
            this.Btn_Init.Click += new System.EventHandler(this.Btn_Init_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(427, 335);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(8, 8);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Btn_Quit
            // 
            this.Btn_Quit.Location = new System.Drawing.Point(546, 328);
            this.Btn_Quit.Name = "Btn_Quit";
            this.Btn_Quit.Size = new System.Drawing.Size(75, 23);
            this.Btn_Quit.TabIndex = 2;
            this.Btn_Quit.Text = "quitter";
            this.Btn_Quit.UseVisualStyleBackColor = true;
            this.Btn_Quit.Click += new System.EventHandler(this.Btn_Quit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "opérand 1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Txt_Op1
            // 
            this.Txt_Op1.Location = new System.Drawing.Point(9, 55);
            this.Txt_Op1.Name = "Txt_Op1";
            this.Txt_Op1.Size = new System.Drawing.Size(100, 20);
            this.Txt_Op1.TabIndex = 4;
            this.Txt_Op1.Text = "2";
            this.Txt_Op1.TextChanged += new System.EventHandler(this.Txt_Op1_TextChanged);
            // 
            // Txt_Op2
            // 
            this.Txt_Op2.Location = new System.Drawing.Point(6, 121);
            this.Txt_Op2.Name = "Txt_Op2";
            this.Txt_Op2.Size = new System.Drawing.Size(100, 20);
            this.Txt_Op2.TabIndex = 5;
            this.Txt_Op2.Text = "3";
            this.Txt_Op2.TextChanged += new System.EventHandler(this.Txt_Op2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "opérand2";
            // 
            // Btn_Add
            // 
            this.Btn_Add.Location = new System.Drawing.Point(134, 22);
            this.Btn_Add.Name = "Btn_Add";
            this.Btn_Add.Size = new System.Drawing.Size(60, 21);
            this.Btn_Add.TabIndex = 7;
            this.Btn_Add.Text = "+";
            this.Btn_Add.UseVisualStyleBackColor = true;
            this.Btn_Add.Click += new System.EventHandler(this.button4_Click);
            // 
            // Btn_Sous
            // 
            this.Btn_Sous.Location = new System.Drawing.Point(134, 59);
            this.Btn_Sous.Name = "Btn_Sous";
            this.Btn_Sous.Size = new System.Drawing.Size(66, 20);
            this.Btn_Sous.TabIndex = 8;
            this.Btn_Sous.Text = "-";
            this.Btn_Sous.UseVisualStyleBackColor = true;
            this.Btn_Sous.Click += new System.EventHandler(this.Btn_Sous_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(606, 105);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 9;
            this.button6.Text = "*";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // Btn_Div
            // 
            this.Btn_Div.Location = new System.Drawing.Point(134, 125);
            this.Btn_Div.Name = "Btn_Div";
            this.Btn_Div.Size = new System.Drawing.Size(66, 18);
            this.Btn_Div.TabIndex = 10;
            this.Btn_Div.Text = "/";
            this.Btn_Div.UseVisualStyleBackColor = true;
            this.Btn_Div.Click += new System.EventHandler(this.button7_Click);
            // 
            // Btn_Mod
            // 
            this.Btn_Mod.Location = new System.Drawing.Point(134, 164);
            this.Btn_Mod.Name = "Btn_Mod";
            this.Btn_Mod.Size = new System.Drawing.Size(68, 17);
            this.Btn_Mod.TabIndex = 11;
            this.Btn_Mod.Text = "%";
            this.Btn_Mod.UseVisualStyleBackColor = true;
            this.Btn_Mod.Click += new System.EventHandler(this.Btn_Mod_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(165, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(192, 245);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Expression";
            // 
            // Txt_Exp
            // 
            this.Txt_Exp.Location = new System.Drawing.Point(266, 242);
            this.Txt_Exp.Name = "Txt_Exp";
            this.Txt_Exp.Size = new System.Drawing.Size(225, 20);
            this.Txt_Exp.TabIndex = 14;
            this.Txt_Exp.TextChanged += new System.EventHandler(this.Txt_Exp_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(192, 282);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Résultat";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // Txt_Res
            // 
            this.Txt_Res.Location = new System.Drawing.Point(266, 282);
            this.Txt_Res.Name = "Txt_Res";
            this.Txt_Res.Size = new System.Drawing.Size(225, 20);
            this.Txt_Res.TabIndex = 16;
            this.Txt_Res.TextChanged += new System.EventHandler(this.Txt_Res_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Txt_Op1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Txt_Op2);
            this.groupBox1.Location = new System.Drawing.Point(66, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(208, 187);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "opérandes";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Btn_Mul);
            this.groupBox2.Controls.Add(this.Btn_Add);
            this.groupBox2.Controls.Add(this.Btn_Sous);
            this.groupBox2.Controls.Add(this.Btn_Div);
            this.groupBox2.Controls.Add(this.Btn_Mod);
            this.groupBox2.Location = new System.Drawing.Point(465, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(232, 187);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "opérateurs";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // Btn_Mul
            // 
            this.Btn_Mul.Location = new System.Drawing.Point(134, 93);
            this.Btn_Mul.Name = "Btn_Mul";
            this.Btn_Mul.Size = new System.Drawing.Size(68, 26);
            this.Btn_Mul.TabIndex = 12;
            this.Btn_Mul.Text = "*";
            this.Btn_Mul.UseVisualStyleBackColor = true;
            this.Btn_Mul.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Txt_Res);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Txt_Exp);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.Btn_Quit);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Btn_Init);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_Init;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Btn_Quit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Txt_Op1;
        private System.Windows.Forms.TextBox Txt_Op2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Btn_Add;
        private System.Windows.Forms.Button Btn_Sous;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button Btn_Div;
        private System.Windows.Forms.Button Btn_Mod;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Txt_Exp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Txt_Res;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Btn_Mul;
    }
}

