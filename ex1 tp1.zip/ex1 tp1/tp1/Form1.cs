﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Txt_Op1.Text) || string.IsNullOrEmpty(Txt_Op2.Text))
            MessageBox.Show("attention:zone vide");
            else
            {
                try
                {
                    int op1 = Convert.ToInt32(Txt_Op1.Text);
                    int op2 = Convert.ToInt32(Txt_Op2.Text);
                    int res = op1 + op2;
                    Txt_Exp.Text = Txt_Op1.Text + " + " + Txt_Op2.Text;
                    Txt_Res.Text = res.ToString();
                }
                catch(Exception ex) {
                    MessageBox.Show(ex.Message);

                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(Txt_Op1.Text) || string.IsNullOrEmpty(Txt_Op2.Text))
                MessageBox.Show("attention:zone vide");
            else
            {
                try
                {
                    int op1 = Convert.ToInt32(Txt_Op1.Text);
                    int op2 = Convert.ToInt32(Txt_Op2.Text);
                    int res = op1 / op2;
                    Txt_Exp.Text = Txt_Op1.Text + " / " + Txt_Op2.Text;
                    Txt_Res.Text = res.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Txt_Op1.Text) || string.IsNullOrEmpty(Txt_Op2.Text))
            MessageBox.Show("attention:zone vide");
            else
            {
                try
                {
                    int op1 = Convert.ToInt32(Txt_Op1.Text);
                    int op2 = Convert.ToInt32(Txt_Op2.Text);
                    int res = op1 * op2;
                    Txt_Exp.Text = Txt_Op1.Text + " * " + Txt_Op2.Text;
                    Txt_Res.Text = res.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
        }

        private void Txt_Op1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Txt_Exp_TextChanged(object sender, EventArgs e)
        {

        }

        private void Btn_Init_Click(object sender, EventArgs e)
        {
            Txt_Op1.Clear();
            Txt_Op2.Clear();
            Txt_Exp.Clear();
            Txt_Res.Clear();
        }

        private void Btn_Sous_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Txt_Op1.Text) || string.IsNullOrEmpty(Txt_Op2.Text))
            MessageBox.Show("attention:zone vide");
            else
            {
                try
                {
                    int op1 = Convert.ToInt32(Txt_Op1.Text);
                    int op2 = Convert.ToInt32(Txt_Op2.Text);
                    int res = op1 - op2;
                    Txt_Exp.Text = Txt_Op1.Text + " - " + Txt_Op2.Text;
                    Txt_Res.Text = res.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }

            }

        }

        private void Btn_Quit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Txt_Op2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Btn_Mod_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Txt_Op1.Text) || string.IsNullOrEmpty(Txt_Op2.Text))
                MessageBox.Show("attention:zone vide");
            else
            {
                try
                {
                    int op1 = Convert.ToInt32(Txt_Op1.Text);
                    int op2 = Convert.ToInt32(Txt_Op2.Text);
                    int res = op1 % op2;
                    Txt_Exp.Text = Txt_Op1.Text + " % " + Txt_Op2.Text;
                    Txt_Res.Text = res.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
        }

        private void Txt_Res_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
