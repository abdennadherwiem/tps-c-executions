﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP3
{
    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();
        }
        public Compte cp;

        private void Btn_Valid_Click(object sender, EventArgs e)
        {
            cp = new Compte()
            {
                numcompte = Txtnumcompte.Text,
                titulaire = Txttitulaire.Text,
                solde = double.Parse(Txtsolde.Text)
            };
            //Fermer le formulaire et revenir au formulaire appelant
            this.Close();

        }

        private void Txtsolde_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                Btn_Valid_Click(sender, e);

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
