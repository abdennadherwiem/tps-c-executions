﻿namespace TP3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Tab_Cl = new System.Windows.Forms.TabControl();
            this.Tab_Cpt = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Dg_Client = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Titulaire = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Solde = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Txt_Tit = new System.Windows.Forms.TextBox();
            this.Txt_Sld = new System.Windows.Forms.TextBox();
            this.Txt_Rech = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Ts_Menu = new System.Windows.Forms.ToolStrip();
            this.Btn_Ajout = new System.Windows.Forms.ToolStripButton();
            this.Btn_Supp = new System.Windows.Forms.ToolStripButton();
            this.Btn_Rech = new System.Windows.Forms.ToolStripButton();
            this.tsbtn_FinRech = new System.Windows.Forms.ToolStripButton();
            this.Tab_Mouv = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Datm = new System.Windows.Forms.DateTimePicker();
            this.Btn_Creer_Mouv = new System.Windows.Forms.Button();
            this.TxtMt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Rdb_Vers = new System.Windows.Forms.RadioButton();
            this.Rdb_Ret = new System.Windows.Forms.RadioButton();
            this.Dg_Mouv = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Txttitulaire = new System.Windows.Forms.TextBox();
            this.TxtSolde = new System.Windows.Forms.TextBox();
            this.Txtnum = new System.Windows.Forms.TextBox();
            this.Tab_Ext = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Dg_Extrait = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Btn_Affiche = new System.Windows.Forms.Button();
            this.Dat_Fin = new System.Windows.Forms.DateTimePicker();
            this.Dat_Deb = new System.Windows.Forms.DateTimePicker();
            this.Txt_Slde = new System.Windows.Forms.TextBox();
            this.Txt_Tite = new System.Windows.Forms.TextBox();
            this.Txt_Nume = new System.Windows.Forms.TextBox();
            this.Numéro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateoper = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.montant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tab_Cl.SuspendLayout();
            this.Tab_Cpt.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Client)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.Ts_Menu.SuspendLayout();
            this.Tab_Mouv.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Mouv)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.Tab_Ext.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Extrait)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tab_Cl
            // 
            this.Tab_Cl.Controls.Add(this.Tab_Cpt);
            this.Tab_Cl.Controls.Add(this.Tab_Mouv);
            this.Tab_Cl.Controls.Add(this.Tab_Ext);
            this.Tab_Cl.Location = new System.Drawing.Point(6, 5);
            this.Tab_Cl.Name = "Tab_Cl";
            this.Tab_Cl.SelectedIndex = 0;
            this.Tab_Cl.Size = new System.Drawing.Size(582, 380);
            this.Tab_Cl.TabIndex = 0;
            this.Tab_Cl.Selected += new System.Windows.Forms.TabControlEventHandler(this.Tab_Cl_Selected);
            // 
            // Tab_Cpt
            // 
            this.Tab_Cpt.BackColor = System.Drawing.SystemColors.Control;
            this.Tab_Cpt.Controls.Add(this.groupBox2);
            this.Tab_Cpt.Controls.Add(this.groupBox1);
            this.Tab_Cpt.Controls.Add(this.Ts_Menu);
            this.Tab_Cpt.Location = new System.Drawing.Point(4, 22);
            this.Tab_Cpt.Name = "Tab_Cpt";
            this.Tab_Cpt.Padding = new System.Windows.Forms.Padding(3);
            this.Tab_Cpt.Size = new System.Drawing.Size(574, 354);
            this.Tab_Cpt.TabIndex = 0;
            this.Tab_Cpt.Text = "Gestion des Comptes Clients";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Dg_Client);
            this.groupBox2.Location = new System.Drawing.Point(89, 120);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(355, 232);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Liste des Comptes";
            // 
            // Dg_Client
            // 
            this.Dg_Client.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dg_Client.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Titulaire,
            this.Solde});
            this.Dg_Client.Location = new System.Drawing.Point(7, 18);
            this.Dg_Client.Name = "Dg_Client";
            this.Dg_Client.RowHeadersWidth = 51;
            this.Dg_Client.RowTemplate.Height = 24;
            this.Dg_Client.Size = new System.Drawing.Size(344, 210);
            this.Dg_Client.TabIndex = 0;
            this.Dg_Client.Click += new System.EventHandler(this.Dg_Client_Click);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Numéro";
            this.Column1.Name = "Column1";
            // 
            // Titulaire
            // 
            this.Titulaire.HeaderText = "Titulaire";
            this.Titulaire.Name = "Titulaire";
            // 
            // Solde
            // 
            this.Solde.HeaderText = "Solde";
            this.Solde.Name = "Solde";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Txt_Tit);
            this.groupBox1.Controls.Add(this.Txt_Sld);
            this.groupBox1.Controls.Add(this.Txt_Rech);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(89, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(355, 110);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Compte Client";
            // 
            // Txt_Tit
            // 
            this.Txt_Tit.Location = new System.Drawing.Point(226, 31);
            this.Txt_Tit.Name = "Txt_Tit";
            this.Txt_Tit.Size = new System.Drawing.Size(129, 20);
            this.Txt_Tit.TabIndex = 5;
            // 
            // Txt_Sld
            // 
            this.Txt_Sld.Location = new System.Drawing.Point(106, 74);
            this.Txt_Sld.Name = "Txt_Sld";
            this.Txt_Sld.Size = new System.Drawing.Size(138, 20);
            this.Txt_Sld.TabIndex = 4;
            // 
            // Txt_Rech
            // 
            this.Txt_Rech.Location = new System.Drawing.Point(51, 31);
            this.Txt_Rech.Name = "Txt_Rech";
            this.Txt_Rech.Size = new System.Drawing.Size(129, 20);
            this.Txt_Rech.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(183, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Titulaire";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(69, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Solde";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numéro";
            // 
            // Ts_Menu
            // 
            this.Ts_Menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.Ts_Menu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.Ts_Menu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Ts_Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Btn_Ajout,
            this.Btn_Supp,
            this.Btn_Rech,
            this.tsbtn_FinRech});
            this.Ts_Menu.Location = new System.Drawing.Point(3, 3);
            this.Ts_Menu.Name = "Ts_Menu";
            this.Ts_Menu.Size = new System.Drawing.Size(91, 348);
            this.Ts_Menu.TabIndex = 0;
            this.Ts_Menu.Text = "toolStrip1";
            // 
            // Btn_Ajout
            // 
            this.Btn_Ajout.Image = ((System.Drawing.Image)(resources.GetObject("Btn_Ajout.Image")));
            this.Btn_Ajout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_Ajout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Btn_Ajout.Name = "Btn_Ajout";
            this.Btn_Ajout.Size = new System.Drawing.Size(88, 24);
            this.Btn_Ajout.Text = "Ajouter";
            this.Btn_Ajout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_Ajout.Click += new System.EventHandler(this.Btn_Ajout_Click);
            // 
            // Btn_Supp
            // 
            this.Btn_Supp.Image = ((System.Drawing.Image)(resources.GetObject("Btn_Supp.Image")));
            this.Btn_Supp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_Supp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Btn_Supp.Name = "Btn_Supp";
            this.Btn_Supp.Size = new System.Drawing.Size(88, 24);
            this.Btn_Supp.Text = "Supprimer";
            this.Btn_Supp.Click += new System.EventHandler(this.Btn_Supp_Click);
            // 
            // Btn_Rech
            // 
            this.Btn_Rech.Image = ((System.Drawing.Image)(resources.GetObject("Btn_Rech.Image")));
            this.Btn_Rech.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_Rech.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Btn_Rech.Name = "Btn_Rech";
            this.Btn_Rech.Size = new System.Drawing.Size(88, 24);
            this.Btn_Rech.Text = "Rechercher";
            this.Btn_Rech.Click += new System.EventHandler(this.Btn_Rech_Click);
            // 
            // tsbtn_FinRech
            // 
            this.tsbtn_FinRech.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbtn_FinRech.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtn_FinRech.Name = "tsbtn_FinRech";
            this.tsbtn_FinRech.Size = new System.Drawing.Size(88, 19);
            this.tsbtn_FinRech.Text = "Fin Recherche";
            this.tsbtn_FinRech.Click += new System.EventHandler(this.tsbtn_FinRech_Click);
            // 
            // Tab_Mouv
            // 
            this.Tab_Mouv.BackColor = System.Drawing.SystemColors.Control;
            this.Tab_Mouv.Controls.Add(this.groupBox4);
            this.Tab_Mouv.Controls.Add(this.groupBox3);
            this.Tab_Mouv.Location = new System.Drawing.Point(4, 22);
            this.Tab_Mouv.Name = "Tab_Mouv";
            this.Tab_Mouv.Padding = new System.Windows.Forms.Padding(3);
            this.Tab_Mouv.Size = new System.Drawing.Size(574, 354);
            this.Tab_Mouv.TabIndex = 1;
            this.Tab_Mouv.Text = "Mouvement Compte";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Datm);
            this.groupBox4.Controls.Add(this.Btn_Creer_Mouv);
            this.groupBox4.Controls.Add(this.TxtMt);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.Dg_Mouv);
            this.groupBox4.Location = new System.Drawing.Point(5, 78);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(567, 274);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Mouvements du Compte";
            // 
            // Datm
            // 
            this.Datm.CustomFormat = "dd/mm/yyyy";
            this.Datm.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.Datm.Location = new System.Drawing.Point(89, 40);
            this.Datm.Name = "Datm";
            this.Datm.Size = new System.Drawing.Size(145, 20);
            this.Datm.TabIndex = 6;
            this.Datm.Value = new System.DateTime(2022, 11, 4, 21, 48, 44, 0);
            // 
            // Btn_Creer_Mouv
            // 
            this.Btn_Creer_Mouv.Location = new System.Drawing.Point(93, 205);
            this.Btn_Creer_Mouv.Name = "Btn_Creer_Mouv";
            this.Btn_Creer_Mouv.Size = new System.Drawing.Size(139, 29);
            this.Btn_Creer_Mouv.TabIndex = 5;
            this.Btn_Creer_Mouv.Text = "Créer mouvement Compte";
            this.Btn_Creer_Mouv.UseVisualStyleBackColor = true;
            this.Btn_Creer_Mouv.Click += new System.EventHandler(this.Btn_Creer_Mouv_Click);
            // 
            // TxtMt
            // 
            this.TxtMt.Location = new System.Drawing.Point(93, 175);
            this.TxtMt.Name = "TxtMt";
            this.TxtMt.Size = new System.Drawing.Size(139, 20);
            this.TxtMt.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 178);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Montant";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Date opération";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Rdb_Vers);
            this.groupBox5.Controls.Add(this.Rdb_Ret);
            this.groupBox5.Location = new System.Drawing.Point(26, 80);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(207, 86);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Type opération";
            // 
            // Rdb_Vers
            // 
            this.Rdb_Vers.AutoSize = true;
            this.Rdb_Vers.Location = new System.Drawing.Point(24, 49);
            this.Rdb_Vers.Name = "Rdb_Vers";
            this.Rdb_Vers.Size = new System.Drawing.Size(75, 17);
            this.Rdb_Vers.TabIndex = 1;
            this.Rdb_Vers.TabStop = true;
            this.Rdb_Vers.Text = "Versement";
            this.Rdb_Vers.UseVisualStyleBackColor = true;
            // 
            // Rdb_Ret
            // 
            this.Rdb_Ret.AutoSize = true;
            this.Rdb_Ret.Location = new System.Drawing.Point(24, 29);
            this.Rdb_Ret.Name = "Rdb_Ret";
            this.Rdb_Ret.Size = new System.Drawing.Size(56, 17);
            this.Rdb_Ret.TabIndex = 0;
            this.Rdb_Ret.TabStop = true;
            this.Rdb_Ret.Text = "Retrait";
            this.Rdb_Ret.UseVisualStyleBackColor = true;
            // 
            // Dg_Mouv
            // 
            this.Dg_Mouv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dg_Mouv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Numéro,
            this.dateop});
            this.Dg_Mouv.Location = new System.Drawing.Point(247, 16);
            this.Dg_Mouv.Name = "Dg_Mouv";
            this.Dg_Mouv.RowHeadersWidth = 51;
            this.Dg_Mouv.RowTemplate.Height = 24;
            this.Dg_Mouv.Size = new System.Drawing.Size(304, 218);
            this.Dg_Mouv.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.Txttitulaire);
            this.groupBox3.Controls.Add(this.TxtSolde);
            this.groupBox3.Controls.Add(this.Txtnum);
            this.groupBox3.Location = new System.Drawing.Point(5, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(567, 68);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Compte Client";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(377, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Solde";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(177, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Titulaire";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Numéro";
            // 
            // Txttitulaire
            // 
            this.Txttitulaire.Location = new System.Drawing.Point(230, 29);
            this.Txttitulaire.Name = "Txttitulaire";
            this.Txttitulaire.Size = new System.Drawing.Size(131, 20);
            this.Txttitulaire.TabIndex = 2;
            // 
            // TxtSolde
            // 
            this.TxtSolde.Location = new System.Drawing.Point(422, 29);
            this.TxtSolde.Name = "TxtSolde";
            this.TxtSolde.Size = new System.Drawing.Size(131, 20);
            this.TxtSolde.TabIndex = 1;
            this.TxtSolde.TextChanged += new System.EventHandler(this.TxtSolde_TextChanged);
            // 
            // Txtnum
            // 
            this.Txtnum.Location = new System.Drawing.Point(50, 29);
            this.Txtnum.Name = "Txtnum";
            this.Txtnum.Size = new System.Drawing.Size(123, 20);
            this.Txtnum.TabIndex = 0;
            // 
            // Tab_Ext
            // 
            this.Tab_Ext.BackColor = System.Drawing.SystemColors.Control;
            this.Tab_Ext.Controls.Add(this.groupBox7);
            this.Tab_Ext.Controls.Add(this.groupBox6);
            this.Tab_Ext.Location = new System.Drawing.Point(4, 22);
            this.Tab_Ext.Name = "Tab_Ext";
            this.Tab_Ext.Size = new System.Drawing.Size(574, 354);
            this.Tab_Ext.TabIndex = 2;
            this.Tab_Ext.Text = "Extrait de Compte";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Dg_Extrait);
            this.groupBox7.Location = new System.Drawing.Point(3, 124);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(572, 230);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Liste des Mouvements";
            // 
            // Dg_Extrait
            // 
            this.Dg_Extrait.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dg_Extrait.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dateoper,
            this.typeop,
            this.montant});
            this.Dg_Extrait.Location = new System.Drawing.Point(57, 29);
            this.Dg_Extrait.Name = "Dg_Extrait";
            this.Dg_Extrait.RowHeadersWidth = 51;
            this.Dg_Extrait.RowTemplate.Height = 24;
            this.Dg_Extrait.Size = new System.Drawing.Size(458, 181);
            this.Dg_Extrait.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.Btn_Affiche);
            this.groupBox6.Controls.Add(this.Dat_Fin);
            this.groupBox6.Controls.Add(this.Dat_Deb);
            this.groupBox6.Controls.Add(this.Txt_Slde);
            this.groupBox6.Controls.Add(this.Txt_Tite);
            this.groupBox6.Controls.Add(this.Txt_Nume);
            this.groupBox6.Location = new System.Drawing.Point(3, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(572, 117);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Compte Client";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(393, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 13);
            this.label13.TabIndex = 10;
            this.label13.Text = "Solde";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(202, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 13);
            this.label12.TabIndex = 9;
            this.label12.Text = "Titulaire";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(21, 31);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 8;
            this.label11.Text = "Numéro";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(251, 76);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 13);
            this.label10.TabIndex = 7;
            this.label10.Text = "Jusqu\'à :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 75);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Extrait de :";
            // 
            // Btn_Affiche
            // 
            this.Btn_Affiche.Location = new System.Drawing.Point(479, 69);
            this.Btn_Affiche.Name = "Btn_Affiche";
            this.Btn_Affiche.Size = new System.Drawing.Size(81, 27);
            this.Btn_Affiche.TabIndex = 5;
            this.Btn_Affiche.Text = "Afficher";
            this.Btn_Affiche.UseVisualStyleBackColor = true;
            this.Btn_Affiche.Click += new System.EventHandler(this.Btn_Affiche_Click);
            // 
            // Dat_Fin
            // 
            this.Dat_Fin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.Dat_Fin.Location = new System.Drawing.Point(303, 75);
            this.Dat_Fin.Name = "Dat_Fin";
            this.Dat_Fin.Size = new System.Drawing.Size(113, 20);
            this.Dat_Fin.TabIndex = 4;
            // 
            // Dat_Deb
            // 
            this.Dat_Deb.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.Dat_Deb.Location = new System.Drawing.Point(80, 75);
            this.Dat_Deb.Name = "Dat_Deb";
            this.Dat_Deb.Size = new System.Drawing.Size(115, 20);
            this.Dat_Deb.TabIndex = 3;
            // 
            // Txt_Slde
            // 
            this.Txt_Slde.Location = new System.Drawing.Point(439, 28);
            this.Txt_Slde.Name = "Txt_Slde";
            this.Txt_Slde.Size = new System.Drawing.Size(121, 20);
            this.Txt_Slde.TabIndex = 2;
            // 
            // Txt_Tite
            // 
            this.Txt_Tite.Location = new System.Drawing.Point(254, 29);
            this.Txt_Tite.Name = "Txt_Tite";
            this.Txt_Tite.Size = new System.Drawing.Size(121, 20);
            this.Txt_Tite.TabIndex = 1;
            // 
            // Txt_Nume
            // 
            this.Txt_Nume.Location = new System.Drawing.Point(72, 29);
            this.Txt_Nume.Name = "Txt_Nume";
            this.Txt_Nume.Size = new System.Drawing.Size(121, 20);
            this.Txt_Nume.TabIndex = 0;
            // 
            // Numéro
            // 
            this.Numéro.HeaderText = "Numéro";
            this.Numéro.Name = "Numéro";
            // 
            // dateop
            // 
            this.dateop.HeaderText = "dateop";
            this.dateop.Name = "dateop";
            // 
            // dateoper
            // 
            this.dateoper.HeaderText = "dateoper";
            this.dateoper.Name = "dateoper";
            // 
            // typeop
            // 
            this.typeop.HeaderText = "typeop";
            this.typeop.Name = "typeop";
            // 
            // montant
            // 
            this.montant.HeaderText = "montant";
            this.montant.Name = "montant";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 397);
            this.Controls.Add(this.Tab_Cl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gestion Des Comptes Bancaires";
            this.Tab_Cl.ResumeLayout(false);
            this.Tab_Cpt.ResumeLayout(false);
            this.Tab_Cpt.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Client)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Ts_Menu.ResumeLayout(false);
            this.Ts_Menu.PerformLayout();
            this.Tab_Mouv.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Mouv)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.Tab_Ext.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Extrait)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl Tab_Cl;
        private System.Windows.Forms.TabPage Tab_Cpt;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip Ts_Menu;
        private System.Windows.Forms.ToolStripButton Btn_Ajout;
        private System.Windows.Forms.ToolStripButton Btn_Supp;
        private System.Windows.Forms.ToolStripButton Btn_Rech;
        private System.Windows.Forms.TabPage Tab_Mouv;
        private System.Windows.Forms.DataGridView Dg_Client;
        private System.Windows.Forms.TextBox Txt_Tit;
        private System.Windows.Forms.TextBox Txt_Sld;
        private System.Windows.Forms.TextBox Txt_Rech;
        private System.Windows.Forms.TabPage Tab_Ext;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView Dg_Mouv;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DateTimePicker Datm;
        private System.Windows.Forms.Button Btn_Creer_Mouv;
        private System.Windows.Forms.TextBox TxtMt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton Rdb_Vers;
        private System.Windows.Forms.RadioButton Rdb_Ret;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Txttitulaire;
        private System.Windows.Forms.TextBox TxtSolde;
        private System.Windows.Forms.TextBox Txtnum;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DataGridView Dg_Extrait;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Btn_Affiche;
        private System.Windows.Forms.DateTimePicker Dat_Fin;
        private System.Windows.Forms.DateTimePicker Dat_Deb;
        private System.Windows.Forms.TextBox Txt_Slde;
        private System.Windows.Forms.TextBox Txt_Tite;
        private System.Windows.Forms.TextBox Txt_Nume;
        private System.Windows.Forms.ToolStripButton tsbtn_FinRech;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Titulaire;
        private System.Windows.Forms.DataGridViewTextBoxColumn Solde;
        private System.Windows.Forms.DataGridViewTextBoxColumn Numéro;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateop;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateoper;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeop;
        private System.Windows.Forms.DataGridViewTextBoxColumn montant;
    }
}

