﻿namespace TP3
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Txtsolde = new System.Windows.Forms.TextBox();
            this.Txttitulaire = new System.Windows.Forms.TextBox();
            this.Txtnumcompte = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Btn_Valid = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Txtsolde);
            this.groupBox1.Controls.Add(this.Txttitulaire);
            this.groupBox1.Controls.Add(this.Txtnumcompte);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Btn_Valid);
            this.groupBox1.Location = new System.Drawing.Point(9, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(244, 207);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Création Nouveau Compte";
            // 
            // Txtsolde
            // 
            this.Txtsolde.Location = new System.Drawing.Point(78, 113);
            this.Txtsolde.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Txtsolde.Name = "Txtsolde";
            this.Txtsolde.Size = new System.Drawing.Size(146, 20);
            this.Txtsolde.TabIndex = 6;
            this.Txtsolde.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txtsolde_KeyPress);
            // 
            // Txttitulaire
            // 
            this.Txttitulaire.Location = new System.Drawing.Point(78, 76);
            this.Txttitulaire.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Txttitulaire.Name = "Txttitulaire";
            this.Txttitulaire.Size = new System.Drawing.Size(146, 20);
            this.Txttitulaire.TabIndex = 5;
            // 
            // Txtnumcompte
            // 
            this.Txtnumcompte.Location = new System.Drawing.Point(78, 42);
            this.Txtnumcompte.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Txtnumcompte.Name = "Txtnumcompte";
            this.Txtnumcompte.Size = new System.Drawing.Size(146, 20);
            this.Txtnumcompte.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 115);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Solde";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 79);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Titulaire";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 45);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Numéro";
            // 
            // Btn_Valid
            // 
            this.Btn_Valid.Location = new System.Drawing.Point(99, 150);
            this.Btn_Valid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn_Valid.Name = "Btn_Valid";
            this.Btn_Valid.Size = new System.Drawing.Size(101, 31);
            this.Btn_Valid.TabIndex = 0;
            this.Btn_Valid.Text = "Valider";
            this.Btn_Valid.UseVisualStyleBackColor = true;
            this.Btn_Valid.Click += new System.EventHandler(this.Btn_Valid_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(262, 227);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form2";
            this.Text = "Fcompte";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox Txtsolde;
        private System.Windows.Forms.TextBox Txttitulaire;
        private System.Windows.Forms.TextBox Txtnumcompte;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Btn_Valid;
    }
}