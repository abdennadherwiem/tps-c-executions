﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3
{
    public class Compte
    {
        public string numcompte { get; set; }
        public string titulaire { get; set; }
        public double solde { get; set; }
        // Liste des Mouvements
        public ArrayList lmouv { get; set; }
        //Constructeur
        public Compte(string num, string titu, double sol)
        {
            numcompte = num;
            titulaire = titu;
            solde = sol;
            lmouv = new ArrayList();
        }
        public Compte()
        {
            lmouv = new ArrayList();
        }
        public void retirer(double val)
        {
            solde = solde - val;
        }
        public void verser(double val)
        {
            solde = solde + val;
        }
        public int NBMouv()
        {
            return lmouv.Count;
        }
        public void NouveauMouv(Mouvements m)
        {
            lmouv.Add(m);
        }
    }
}
