﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP3
{
    public class ListCompte
    {
        public List<Compte> _LCompte { get; set; }
        public ListCompte()
        {
            _LCompte = new List<Compte>();
        }
        public void Ajouter(Compte C) { _LCompte.Add(C); }
        public void Supprimer(int i) { _LCompte.RemoveAt(i); }
        public void supprimer(Compte c) { _LCompte.Remove(c); }
        public int Taille() { return _LCompte.Count; }
        public Compte Element(int i) { return _LCompte[i]; }
        public void Modifier_Solde(int i, double solde)
        {
            _LCompte[i].solde = solde;
        }
        public Compte Rechercher(string Num, out int ind)
        {
            Compte c = new Compte();
            ind = -1;
            for (int i = 0; i < _LCompte.Count; i++)
            {
                c = (Compte)_LCompte[i];
                if (c.numcompte == Num)
                {
                    ind = i;
                    return c;
                }
            }
            return null;
        }
    }
}
