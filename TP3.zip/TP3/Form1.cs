﻿using TP3;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace TP3
{
    public partial class Form1 : Form
    {
        Compte c;
        ListCompte LCompte = new ListCompte();
        int ind;
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn_Ajout_Click(object sender, EventArgs e)
        {
            Form2 myForm = new Form2();
            myForm.ShowDialog();
            LCompte.Ajouter(myForm.cp);
            Dg_Client.Rows.Add(myForm.cp.numcompte, myForm.cp.titulaire, myForm.cp.solde);
        }

       

        private void Btn_Supp_Click(object sender, EventArgs e)
        {
            LCompte.Supprimer(ind);
            Dg_Client.Rows.RemoveAt(ind);
            Txt_Rech.Clear();
            Txt_Tit.Clear();
            Txt_Sld.Clear();

        }


        private void Dg_Client_Click(object sender, EventArgs e)
        {
            ind = Dg_Client.CurrentRow.Index;
            Txt_Rech.Text = Dg_Client[0, ind].Value.ToString();
            Txt_Tit.Text = Dg_Client[1, ind].Value.ToString();
            Txt_Sld.Text = Dg_Client[2, ind].Value.ToString();
            c = LCompte.Element(ind);
        }

        private void Btn_Rech_Click(object sender, EventArgs e)
        {
            if (LCompte.Taille() == 0)
                MessageBox.Show("La liste est vide");
            else
            {
                c = LCompte.Rechercher(Txt_Rech.Text, out ind);
                if (c == null)
                    MessageBox.Show("Numéro inexistant");
                else
                {
                    Txt_Tit.Text = c.titulaire;
                    Txt_Sld.Text = c.solde.ToString();
                }
            }

        }

        private void tsbtn_FinRech_Click(object sender, EventArgs e)
        {
            Txt_Rech.Clear();
            Txt_Tit.Clear();
            Txt_Sld.Clear();

        }


        private void Tab_Cl_Selected(object sender, TabControlEventArgs e)
        {
            if (e.TabPageIndex == 1)
            {
                Txtnum.Text = c.numcompte;
                Txttitulaire.Text = c.titulaire;
                TxtSolde.Text = c.solde.ToString();
                Dg_Mouv.Rows.Clear();
                for (int i = 0; i < c.lmouv.Count; i++)
                {
                    Mouvements m = (Mouvements)c.lmouv[i];
                    Dg_Mouv.Rows.Add(m.dateop, m.typop, m.montant);
                }
            }
            else
            if (e.TabPageIndex == 2)
            {
                Txt_Nume.Text = c.numcompte;
                Txt_Tite.Text = c.titulaire;
                //Txt_Slde.Text = c.solde.ToString();
                //Dg_Extrait.Rows.Clear();
            }

        }

        private void Btn_Creer_Mouv_Click(object sender, EventArgs e)
        {
            string op = "";
            if (!Rdb_Ret.Checked && !Rdb_Vers.Checked)
                MessageBox.Show("Vous devez choisir le type du mouvement");
            else
            {
                if (Rdb_Ret.Checked)
                {
                    op = "Retrait";
                    if (Convert.ToDouble(TxtMt.Text) > c.solde)
                        MessageBox.Show("Solde insuffisant");
                    else
                        c.retirer(Convert.ToDouble(Txtnum.Text));
                        Mouvements m = new Mouvements(Datm.Value, op, Convert.ToDouble(Txtnum.Text));
                        c.NouveauMouv(m);
                        Dg_Mouv.Rows.Add(Datm.Value, op, Txtnum.Text);
                        TxtSolde.Text = Convert.ToString(c.solde);
                        LCompte.Modifier_Solde(ind, c.solde);
                        Dg_Client[2, ind].Value = TxtSolde.Text;
                        TxtSolde.Text = TxtSolde.Text;
                        Txtnum.Clear();
                        Rdb_Ret.Checked = false;
                }
                else
                if (Rdb_Vers.Checked)
                {
                    op = "Versement";
                    c.verser(Convert.ToDouble(Txtnum.Text));
                    Mouvements m1 = new Mouvements(Datm.Value, op, Convert.ToDouble(Txtnum.Text));
                    c.NouveauMouv(m1);
                    Dg_Mouv.Rows.Add(Datm.Value, op, Txtnum.Text);
                    TxtSolde.Text = Convert.ToString(c.solde);
                    LCompte.Modifier_Solde(ind, c.solde);
                    Dg_Client[2, ind].Value = TxtSolde.Text;
                    TxtSolde.Text = TxtSolde.Text;
                    Txtnum.Clear();
                    Rdb_Vers.Checked = false;
                }
               
            }
        }

        private void Btn_Affiche_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < c.lmouv.Count; i++)
            {
                Mouvements m = (Mouvements)c.lmouv[i];
                if (m.dateop >= Dat_Deb.Value && m.dateop <= Dat_Fin.Value)
                    if (m.typop == "Retrait")
                        Dg_Extrait.Rows.Add(m.dateop, m.typop, m.montant);
                    else
                        Dg_Extrait.Rows.Add(m.dateop, m.typop, m.montant);
            }

        }

        private void TxtSolde_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
