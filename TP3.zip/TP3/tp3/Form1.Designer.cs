﻿namespace tp3
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Dg_Mouv = new System.Windows.Forms.DataGridView();
            this.Date_Opérateur = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Type_Mouvement = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Montant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Btn_Creer_Mouv = new System.Windows.Forms.Button();
            this.TxtMt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Rdh_Vers = new System.Windows.Forms.RadioButton();
            this.Rdh_Ret = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.Datm = new System.Windows.Forms.DateTimePicker();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.TxtSolde = new System.Windows.Forms.TextBox();
            this.Txttitulaire = new System.Windows.Forms.TextBox();
            this.Txtnum = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Numéro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Titulaire = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.solde = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.gestion = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Dg_Extrait = new System.Windows.Forms.DataGridView();
            this.Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.solde_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Débit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Crédit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.Txt_Slde = new System.Windows.Forms.TextBox();
            this.Txt_Tite = new System.Windows.Forms.TextBox();
            this.Txt_Nume = new System.Windows.Forms.TextBox();
            this.Btn_Affiche = new System.Windows.Forms.Button();
            this.Dat_Fin = new System.Windows.Forms.DateTimePicker();
            this.Dat_Deb = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Mouv)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.toolStrip2.SuspendLayout();
            this.gestion.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Extrait)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(920, 417);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Mouvement Compte";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Dg_Mouv);
            this.groupBox4.Controls.Add(this.Btn_Creer_Mouv);
            this.groupBox4.Controls.Add(this.TxtMt);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.Datm);
            this.groupBox4.Location = new System.Drawing.Point(29, 123);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(871, 273);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Mouvements du Compte";
            // 
            // Dg_Mouv
            // 
            this.Dg_Mouv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dg_Mouv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Date_Opérateur,
            this.Type_Mouvement,
            this.Montant});
            this.Dg_Mouv.Location = new System.Drawing.Point(339, 33);
            this.Dg_Mouv.Name = "Dg_Mouv";
            this.Dg_Mouv.RowHeadersWidth = 51;
            this.Dg_Mouv.RowTemplate.Height = 24;
            this.Dg_Mouv.Size = new System.Drawing.Size(515, 229);
            this.Dg_Mouv.TabIndex = 8;
            // 
            // Date_Opérateur
            // 
            this.Date_Opérateur.HeaderText = "Date_Opérateur ";
            this.Date_Opérateur.MinimumWidth = 6;
            this.Date_Opérateur.Name = "Date_Opérateur";
            this.Date_Opérateur.Width = 125;
            // 
            // Type_Mouvement
            // 
            this.Type_Mouvement.HeaderText = "Type_Mouvement";
            this.Type_Mouvement.MinimumWidth = 6;
            this.Type_Mouvement.Name = "Type_Mouvement";
            this.Type_Mouvement.Width = 125;
            // 
            // Montant
            // 
            this.Montant.HeaderText = "Montant";
            this.Montant.MinimumWidth = 6;
            this.Montant.Name = "Montant";
            this.Montant.Width = 125;
            // 
            // Btn_Creer_Mouv
            // 
            this.Btn_Creer_Mouv.Location = new System.Drawing.Point(29, 227);
            this.Btn_Creer_Mouv.Name = "Btn_Creer_Mouv";
            this.Btn_Creer_Mouv.Size = new System.Drawing.Size(234, 36);
            this.Btn_Creer_Mouv.TabIndex = 7;
            this.Btn_Creer_Mouv.Text = "Créér mouvement Compte";
            this.Btn_Creer_Mouv.UseVisualStyleBackColor = true;
            this.Btn_Creer_Mouv.Click += new System.EventHandler(this.Btn_Creer_Mouv_Click);
            // 
            // TxtMt
            // 
            this.TxtMt.Location = new System.Drawing.Point(104, 196);
            this.TxtMt.Name = "TxtMt";
            this.TxtMt.Size = new System.Drawing.Size(159, 22);
            this.TxtMt.TabIndex = 6;
            this.TxtMt.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(41, 199);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 16);
            this.label8.TabIndex = 5;
            this.label8.Text = "Montant";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Rdh_Vers);
            this.groupBox5.Controls.Add(this.Rdh_Ret);
            this.groupBox5.Location = new System.Drawing.Point(20, 81);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(243, 104);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Type opération";
            // 
            // Rdh_Vers
            // 
            this.Rdh_Vers.AutoSize = true;
            this.Rdh_Vers.Location = new System.Drawing.Point(38, 59);
            this.Rdh_Vers.Name = "Rdh_Vers";
            this.Rdh_Vers.Size = new System.Drawing.Size(93, 20);
            this.Rdh_Vers.TabIndex = 3;
            this.Rdh_Vers.TabStop = true;
            this.Rdh_Vers.Text = "Versement";
            this.Rdh_Vers.UseVisualStyleBackColor = true;
            // 
            // Rdh_Ret
            // 
            this.Rdh_Ret.AutoSize = true;
            this.Rdh_Ret.Location = new System.Drawing.Point(38, 21);
            this.Rdh_Ret.Name = "Rdh_Ret";
            this.Rdh_Ret.Size = new System.Drawing.Size(67, 20);
            this.Rdh_Ret.TabIndex = 2;
            this.Rdh_Ret.TabStop = true;
            this.Rdh_Ret.Text = "Retrait";
            this.Rdh_Ret.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "Date opération";
            // 
            // Datm
            // 
            this.Datm.Location = new System.Drawing.Point(107, 46);
            this.Datm.Name = "Datm";
            this.Datm.Size = new System.Drawing.Size(200, 22);
            this.Datm.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.TxtSolde);
            this.groupBox3.Controls.Add(this.Txttitulaire);
            this.groupBox3.Controls.Add(this.Txtnum);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(29, 22);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(871, 79);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Compte Client";
            // 
            // TxtSolde
            // 
            this.TxtSolde.Location = new System.Drawing.Point(532, 40);
            this.TxtSolde.Name = "TxtSolde";
            this.TxtSolde.Size = new System.Drawing.Size(144, 22);
            this.TxtSolde.TabIndex = 5;
            // 
            // Txttitulaire
            // 
            this.Txttitulaire.Location = new System.Drawing.Point(330, 40);
            this.Txttitulaire.Name = "Txttitulaire";
            this.Txttitulaire.Size = new System.Drawing.Size(144, 22);
            this.Txttitulaire.TabIndex = 4;
            // 
            // Txtnum
            // 
            this.Txtnum.Location = new System.Drawing.Point(119, 40);
            this.Txtnum.Name = "Txtnum";
            this.Txtnum.Size = new System.Drawing.Size(144, 22);
            this.Txtnum.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(482, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Solde";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(269, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Titulaire";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(50, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Numéro";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.toolStrip2);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(920, 417);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Gestion des Comptes Clients ";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(133, 20);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(488, 156);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Compte Client";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(168, 96);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(121, 22);
            this.textBox3.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(293, 37);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(121, 22);
            this.textBox2.TabIndex = 4;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(81, 37);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(121, 22);
            this.textBox1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(119, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Solde";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(232, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Titulaire";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numéro";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Location = new System.Drawing.Point(133, 203);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(499, 211);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Liste des comptes";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Numéro,
            this.Titulaire,
            this.solde});
            this.dataGridView1.Location = new System.Drawing.Point(6, 21);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(486, 184);
            this.dataGridView1.TabIndex = 1;
            // 
            // Numéro
            // 
            this.Numéro.HeaderText = "Numéro";
            this.Numéro.MinimumWidth = 6;
            this.Numéro.Name = "Numéro";
            this.Numéro.Width = 125;
            // 
            // Titulaire
            // 
            this.Titulaire.HeaderText = "Titulaire";
            this.Titulaire.MinimumWidth = 6;
            this.Titulaire.Name = "Titulaire";
            this.Titulaire.Width = 125;
            // 
            // solde
            // 
            this.solde.HeaderText = "solde";
            this.solde.MinimumWidth = 6;
            this.solde.Name = "solde";
            this.solde.Width = 125;
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.Left;
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton6});
            this.toolStrip2.Location = new System.Drawing.Point(3, 3);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(107, 411);
            this.toolStrip2.TabIndex = 0;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(104, 24);
            this.toolStripButton3.Text = "Ajouter";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(104, 24);
            this.toolStripButton4.Text = "Supprimer";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(104, 24);
            this.toolStripButton5.Text = "Rechercher";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(104, 24);
            this.toolStripButton6.Text = "Fin Recherche";
            // 
            // gestion
            // 
            this.gestion.Controls.Add(this.tabPage1);
            this.gestion.Controls.Add(this.tabPage2);
            this.gestion.Controls.Add(this.tabPage3);
            this.gestion.Location = new System.Drawing.Point(12, 3);
            this.gestion.Name = "gestion";
            this.gestion.SelectedIndex = 0;
            this.gestion.Size = new System.Drawing.Size(928, 446);
            this.gestion.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(920, 417);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Extrait de Compte";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Dg_Extrait);
            this.groupBox7.Location = new System.Drawing.Point(16, 132);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(747, 278);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Liste des Mouvement";
            // 
            // Dg_Extrait
            // 
            this.Dg_Extrait.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dg_Extrait.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Type,
            this.solde_,
            this.Débit,
            this.Crédit});
            this.Dg_Extrait.Location = new System.Drawing.Point(29, 42);
            this.Dg_Extrait.Name = "Dg_Extrait";
            this.Dg_Extrait.RowHeadersWidth = 51;
            this.Dg_Extrait.RowTemplate.Height = 24;
            this.Dg_Extrait.Size = new System.Drawing.Size(686, 211);
            this.Dg_Extrait.TabIndex = 0;
            this.Dg_Extrait.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // Type
            // 
            this.Type.HeaderText = "Type";
            this.Type.MinimumWidth = 6;
            this.Type.Name = "Type";
            this.Type.Width = 125;
            // 
            // solde_
            // 
            this.solde_.HeaderText = "solde_";
            this.solde_.MinimumWidth = 6;
            this.solde_.Name = "solde_";
            this.solde_.Width = 125;
            // 
            // Débit
            // 
            this.Débit.HeaderText = "Débit";
            this.Débit.MinimumWidth = 6;
            this.Débit.Name = "Débit";
            this.Débit.Width = 125;
            // 
            // Crédit
            // 
            this.Crédit.HeaderText = "Crédit";
            this.Crédit.MinimumWidth = 6;
            this.Crédit.Name = "Crédit";
            this.Crédit.Width = 125;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.Txt_Slde);
            this.groupBox6.Controls.Add(this.Txt_Tite);
            this.groupBox6.Controls.Add(this.Txt_Nume);
            this.groupBox6.Controls.Add(this.Btn_Affiche);
            this.groupBox6.Controls.Add(this.Dat_Fin);
            this.groupBox6.Controls.Add(this.Dat_Deb);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Location = new System.Drawing.Point(16, 22);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(747, 104);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Compte Client";
            // 
            // Txt_Slde
            // 
            this.Txt_Slde.Location = new System.Drawing.Point(537, 35);
            this.Txt_Slde.Name = "Txt_Slde";
            this.Txt_Slde.Size = new System.Drawing.Size(100, 22);
            this.Txt_Slde.TabIndex = 10;
            // 
            // Txt_Tite
            // 
            this.Txt_Tite.Location = new System.Drawing.Point(328, 38);
            this.Txt_Tite.Name = "Txt_Tite";
            this.Txt_Tite.Size = new System.Drawing.Size(100, 22);
            this.Txt_Tite.TabIndex = 9;
            // 
            // Txt_Nume
            // 
            this.Txt_Nume.Location = new System.Drawing.Point(123, 38);
            this.Txt_Nume.Name = "Txt_Nume";
            this.Txt_Nume.Size = new System.Drawing.Size(100, 22);
            this.Txt_Nume.TabIndex = 8;
            // 
            // Btn_Affiche
            // 
            this.Btn_Affiche.Location = new System.Drawing.Point(619, 72);
            this.Btn_Affiche.Name = "Btn_Affiche";
            this.Btn_Affiche.Size = new System.Drawing.Size(75, 23);
            this.Btn_Affiche.TabIndex = 7;
            this.Btn_Affiche.Text = "Afficher";
            this.Btn_Affiche.UseVisualStyleBackColor = true;
            // 
            // Dat_Fin
            // 
            this.Dat_Fin.Location = new System.Drawing.Point(400, 70);
            this.Dat_Fin.Name = "Dat_Fin";
            this.Dat_Fin.Size = new System.Drawing.Size(200, 22);
            this.Dat_Fin.TabIndex = 6;
            this.Dat_Fin.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // Dat_Deb
            // 
            this.Dat_Deb.Location = new System.Drawing.Point(123, 69);
            this.Dat_Deb.Name = "Dat_Deb";
            this.Dat_Deb.Size = new System.Drawing.Size(200, 22);
            this.Dat_Deb.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(337, 70);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 16);
            this.label13.TabIndex = 4;
            this.label13.Text = "Jusqu\'à:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(45, 70);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 16);
            this.label12.TabIndex = 3;
            this.label12.Text = "Extrait de:";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(466, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 16);
            this.label11.TabIndex = 2;
            this.label11.Text = "Solde";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(257, 41);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "Titulaire";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(45, 41);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 16);
            this.label9.TabIndex = 0;
            this.label9.Text = "Numéro";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(945, 450);
            this.Controls.Add(this.gestion);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Mouv)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.gestion.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Extrait)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl gestion;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Numéro;
        private System.Windows.Forms.DataGridViewTextBoxColumn Titulaire;
        private System.Windows.Forms.DataGridViewTextBoxColumn solde;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox TxtSolde;
        private System.Windows.Forms.TextBox Txttitulaire;
        private System.Windows.Forms.TextBox Txtnum;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Btn_Creer_Mouv;
        private System.Windows.Forms.TextBox TxtMt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton Rdh_Vers;
        private System.Windows.Forms.RadioButton Rdh_Ret;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker Datm;
        private System.Windows.Forms.DataGridView Dg_Mouv;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date_Opérateur;
        private System.Windows.Forms.DataGridViewTextBoxColumn Type_Mouvement;
        private System.Windows.Forms.DataGridViewTextBoxColumn Montant;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DateTimePicker Dat_Fin;
        private System.Windows.Forms.DateTimePicker Dat_Deb;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView Dg_Extrait;
        private System.Windows.Forms.TextBox Txt_Slde;
        private System.Windows.Forms.TextBox Txt_Tite;
        private System.Windows.Forms.TextBox Txt_Nume;
        private System.Windows.Forms.Button Btn_Affiche;
        private System.Windows.Forms.DataGridViewTextBoxColumn Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn solde_;
        private System.Windows.Forms.DataGridViewTextBoxColumn Débit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Crédit;
    }
}

