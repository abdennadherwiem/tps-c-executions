﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace tp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }
        ListCompte lc = new ListCompte();
        Compte c;
        private int ind;
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            c = new Compte(textBox1.Text, textBox2.Text, double.Parse(textBox3.Text));
            lc.Ajouter(c);
            dataGridView1.Rows.Add(c.numero_compte, c.titulaie_compte, c.solde_compte);
        }


        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {

                int selectedIndex = dataGridView1.SelectedRows[0].Index;


                dataGridView1.Rows.RemoveAt(selectedIndex);



            }
            else
            {
                MessageBox.Show("Aucune ligne sélectionnée à supprimer.");
            }
        }
       







        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            string numCRech = textBox1.Text;

            // Recherchez le compte dans la liste lc
            Compte compteRecherche = lc.Recherche(numCRech);

            if (compteRecherche != null)
            {
                // Affichez les informations du compte recherché dans les zones de texte
                textBox2.Text = compteRecherche.titulaie_compte;
                textBox3.Text = compteRecherche.solde_compte.ToString();
            }
            else
            {
                MessageBox.Show("Le compte n'a pas été trouvé !!");

            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Btn_Creer_Mouv_Click(object sender, EventArgs e)
        {
            string op = "";
            if (!Rdh_Ret.Checked && !Rdh_Vers.Checked)
                MessageBox.Show("Vous devez choisir le type du mouvement");
            else
            {
                if (Rdh_Ret.Checked)
                {
                    op = "Retrait";
                    if (Convert.ToDouble(TxtMt.Text) > c.solde_compte)
                        MessageBox.Show("Solde insuffisant");
                    else
                        c.retirer(Convert.ToDouble(Txtnum.Text));
                    Mouvements m = new Mouvements(Datm.Value, op, Convert.ToDouble(Txtnum.Text));
                    c.NouveauMouv(m);
                    Dg_Mouv.Rows.Add(Datm.Value, op, Txtnum.Text);
                    TxtSolde.Text = Convert.ToString(c.solde_compte);
                    lc.Modifier_Solde(ind, c.solde_compte);
                    dataGridView1[2, ind].Value = TxtSolde.Text;
                    TxtSolde.Text = TxtSolde.Text;
                    Txtnum.Clear();
                    Rdh_Ret.Checked = false;
                }
                else
                if (Rdh_Vers.Checked)
                {
                    op = "Versement";
                    c.verser(Convert.ToDouble(Txtnum.Text));
                    Mouvements m1 = new Mouvements(Datm.Value, op, Convert.ToDouble(Txtnum.Text));
                    c.NouveauMouv(m1);
                    Dg_Mouv.Rows.Add(Datm.Value, op, Txtnum.Text);
                    TxtSolde.Text = Convert.ToString(c.solde_compte);
                    lc.Modifier_Solde(ind, c.solde_compte);
                    dataGridView1[2, ind].Value = TxtSolde.Text;
                    TxtSolde.Text = TxtSolde.Text;
                    Txtnum.Clear();
                    Rdh_Vers.Checked = false;
                }

            }
        }
    }
}

