﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tp3
{
    public class Compte
    {
        private List<Mouvements> lmouv;
        private string numcompte;
        private double solde;
        private string titulaire;
        public Compte (string numcompte,string titulaire,double solde)
        {
            this.numcompte = numcompte;
            this.solde= solde;
            this.titulaire= titulaire;
            lmouv = new List<Mouvements>();
        }
        public Compte()
        {
            lmouv=new List<Mouvements>();
        }
        public string numero_compte
        {
            get { return numcompte; }
            set { numcompte = value; }
        }
        public string titulaie_compte
        {
            get { return titulaire; }
            set { titulaire = value; }
        }
        public double solde_compte
        {
            get { return solde; }
            set { solde = value; }
        }
        public List<Mouvements> list_mouv
        {
            get { return lmouv; }
            set { lmouv = value; }
        }
        public void retirer(double val)
        {
            solde = solde - val;
        }
        public void verser(double val)
        {
            solde = solde + val;
        }
        public int NBMouv()
        {
            return lmouv.Count;
        }
        public void NouveauMouv(Mouvements m)
        {
            lmouv.Add(m);

        }
    }
}
