﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tp3
{
    public class ListCompte
    {
        private List<Compte> _LCompte;
        internal int count;

        public ListCompte()
        {
            _LCompte = new List<Compte>();
        }
        public List<Compte> LCompte
        {
            get { return _LCompte; }

            set { _LCompte = value; }

        }

        public void Ajouter(Compte C)
        {
            _LCompte.Add(C);
        }

        public void Supprimer(int i)
        {
            if (i >= 0 && i < _LCompte.Count)
                _LCompte.RemoveAt(i);
        }
        public void supprimer(Compte c)
        {
            _LCompte.Remove(c);
        }

        public Compte Recherche(string numcompte)
        {
            Compte c = null;
            if (_LCompte.Count == 0)
                return null;
            else
            {
                foreach (Compte compte in _LCompte)
                {
                    if (compte.numero_compte == numcompte)
                    {
                        c = compte;
                        break;
                    }

                }
                return c;

            }

        }
        public void Modifier_Solde(int i, double solde)
        {
            _LCompte[i].solde_compte = solde;
        }


    }
}
