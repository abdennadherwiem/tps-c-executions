﻿using System;


namespace TP3
{
    public class Mouvements
    {
        public DateTime dateop { get; set; }
        public string typop { get; set; }
        public double montant { get; set; }
        public Mouvements(DateTime dop, string type, double mt)
        {
            dateop = dop;
            typop = type;
            montant = mt;
        }
    }
}
