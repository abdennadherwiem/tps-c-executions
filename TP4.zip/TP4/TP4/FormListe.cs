﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP5.ADO;

namespace TP5
{
    public partial class FormListe : MetroFramework.Forms.MetroForm
    {
        public FormListe()
        {
            InitializeComponent();
        }

        private void FormListe_Load(object sender, EventArgs e)
        {
            Connexion.Ouvrir();
            //MessageBox.Show(Connexion.cn.State.ToString());
        }



        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.MdiParent= this;
            f.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormListe_FormClosed(object sender, FormClosedEventArgs e)
        {
            Connexion.Fermer();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Form_Produit f = new Form_Produit();
            f.MdiParent = this;
            f.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            FCommande f = new FCommande();
            f.MdiParent = this;
            f.Show();
        }
    }
}
