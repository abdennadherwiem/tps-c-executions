﻿using MetroFramework.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP5.ADO;
using TP5.METIER;

namespace TP5
{
    public partial class Form_Produit : MetroFramework.Forms.MetroForm
    {
       public static Form_Produit instance;
       public MetroTextBox mt1;
        public MetroTextBox mt2;
        public MetroTextBox mt3;
        public Produit pp;
        public Form_Produit()
        {
            InitializeComponent();
            mt1 = metroTextBox1;
            mt2 = metroTextBox2;
            mt3 = metroTextBox3;
            pp= new Produit();
        }

        private void Form_Produit_Load(object sender, EventArgs e)
        {
            metroGrid1.DataSource = ProduitADO.Liste_Client();
            metroTextBox1.Focus();
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            AjoutP ajoutP = new AjoutP();
            ajoutP.ShowDialog();
            metroGrid1.DataSource = ProduitADO.Liste_Client();
        }

        private void metroButton4_Click(object sender, EventArgs e)
        {
            Modif_Produit ajoutP = new Modif_Produit();
            ajoutP.ShowDialog();
            metroGrid1.DataSource = ProduitADO.Liste_Client();
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            ProduitADO clado = new ProduitADO();
            Produit P = new Produit();
            P.Ref_Prod = Convert.ToInt32(metroTextBox1.Text);
            clado.Supprimer(P.Ref_Prod);
            MessageBox.Show("client supprimer");
            metroGrid1.DataSource = ProduitADO.Liste_Client();
            metroTextBox1.Clear();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            Produit P = new Produit();
            P.Ref_Prod = Convert.ToInt32(metroTextBox1.Text);
            bool a;
            a = ProduitADO.Existe_Client(P.Ref_Prod);
            if (a == true)
            {
                MessageBox.Show("Produit trouver");
                metroGrid1.DataSource = ProduitADO.Liste_Client(P.Ref_Prod);
            }
            else
                MessageBox.Show("Produit non trouver");
            metroTextBox1.Clear();
            metroTextBox1.Focus();
            metroTextBox2.Clear();
            metroTextBox3.Clear();
        }

        private void metroButton5_Click(object sender, EventArgs e)
        {
            metroTextBox1.Clear();
            metroTextBox1.Focus();
            metroTextBox2.Clear();
            metroTextBox3.Clear();
        }

        private void metroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = metroGrid1.Rows[e.RowIndex];
                metroTextBox1.Text = row.Cells["Ref_Prod"].Value.ToString();
                metroTextBox2.Text = row.Cells["Desig_Prod"].Value.ToString();
                metroTextBox3.Text = row.Cells["Categ_Prod"].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pp.Ref_Prod = Convert.ToInt64(metroTextBox1.Text);
            pp.Desig_Produit = metroTextBox2.Text;
            pp.Prix_Prod = float.Parse(metroTextBox4.Text);
            MessageBox.Show("PP RECUPERER");
            FCommande.instance.mg1.Rows.Add(Form_Produit.instance.pp.Ref_Prod, Form_Produit.instance.pp.Prix_Prod,Form_Produit.instance.pp.Categ_Produit);
        }
    }
}
