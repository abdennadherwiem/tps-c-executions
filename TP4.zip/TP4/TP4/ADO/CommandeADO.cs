﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP5.ADO;
using TP5.METIER;

namespace TP5.ADO
{
    class CommandeADO
    {
        public static bool Existe_Client(Int32 numC)
        {
            SqlCommand cverif = new SqlCommand("select * from Commande where Num_Cde = @numC", Connexion.cn);
            cverif.Parameters.AddWithValue("@numC", numC);
            SqlDataReader drverif = cverif.ExecuteReader();
            if (drverif.HasRows == true)
            {
                drverif.Close();
                return true;
            }
            else
            {
                drverif.Close();
                return false;
            }
        }

        public void Inserer(Commande C)
        {
            SqlCommand cmdaj = new SqlCommand("insert into Commande (Num_Cde,CIN,Date_Cde) values (@Num,@cin,@date)", Connexion.cn);
            cmdaj.Parameters.AddWithValue("@Num", C.num_C);
            cmdaj.Parameters.AddWithValue("@cin", C.cinC);
            cmdaj.Parameters.AddWithValue("@date",C.DateC);
            cmdaj.ExecuteNonQuery();
        }
    }
}
