﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP5.ADO;
using TP5.METIER;
namespace TP5.ADO
{
    public class ProduitADO
    {
        public static DataTable Liste_Client()
        {
            DataTable dtcl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select * from Produit", Connexion.cn);
            da.Fill(dtcl);
            return dtcl;
        }

        public void Inserer(Produit P)
        {
            SqlCommand cmdaj = new SqlCommand("insert into Produit values (@Ref,@Desig,@Categ,@Prix,@Qte)", Connexion.cn);
            cmdaj.Parameters.AddWithValue("@Ref", P.Ref_Prod);
            cmdaj.Parameters.AddWithValue("@Desig", P.Desig_Produit);
            cmdaj.Parameters.AddWithValue("@Categ", P.Categ_Produit);
            cmdaj.Parameters.AddWithValue("@Prix", P.Prix_Prod);
            cmdaj.Parameters.AddWithValue("@Qte", P.Qte_Produit);
            cmdaj.ExecuteNonQuery();
        }

        public void Modifier(Produit P)
        {
            string req = "update Produit set Desig_Prod=@Desig,Categ_Prod=@Categ, PrixV_Prod=@Prix, Qte_Prod=@Qte where Ref_Prod =@Ref";
            SqlCommand cmdmaj = new SqlCommand(req, Connexion.cn);
            cmdmaj.Parameters.AddWithValue("@Ref", P.Ref_Prod);
            cmdmaj.Parameters.AddWithValue("@Desig", P.Desig_Produit);
            cmdmaj.Parameters.AddWithValue("@Categ", P.Categ_Produit);
            cmdmaj.Parameters.AddWithValue("@Prix", P.Prix_Prod);
            cmdmaj.Parameters.AddWithValue("@Qte", P.Qte_Produit);
            cmdmaj.ExecuteNonQuery();
        }

        public void Supprimer(Int64 Ref)
        {
            string req = "delete from Produit where Ref_Prod = @Ref";
            SqlCommand cmdsupp = new SqlCommand(req, Connexion.cn);
            cmdsupp.Parameters.AddWithValue("@Ref", Ref);
            cmdsupp.ExecuteNonQuery();
        }

        public static bool Existe_Client(Int64 Ref)
        {
            SqlCommand cverif = new SqlCommand("select * from Produit where Ref_Prod = @Ref", Connexion.cn);
            cverif.Parameters.AddWithValue("@Ref", Ref);
            SqlDataReader drverif = cverif.ExecuteReader();
            if (drverif.HasRows == true)
            {
                drverif.Close();
                return true;
            }
            else
            {
                drverif.Close();
                return false;
            }
        }

        public static DataTable Liste_Client(Int64 Ref)
        {
            DataTable dtcl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select * from Produit where Ref_Prod=@Ref", Connexion.cn);
            da.SelectCommand.Parameters.AddWithValue("@Ref", Ref);
            da.Fill(dtcl);
            return dtcl;
        }
    }
}
