﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP5.ADO;
using TP5.METIER;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TP5
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            metroGrid1.DataSource = ClientADO.Liste_Client();
            metroTextBox1.Focus();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Client cl = new Client();
            ClientADO clientADO = new ClientADO();
            cl.Cin_Cl = Convert.ToInt32(metroTextBox1.Text);
            cl.Nom_Cl = metroTextBox2.Text;
            cl.Pren_Cl = metroTextBox5.Text;
            cl.Ville_Cl = metroTextBox3.Text;
            cl.Tel_Cl = Convert.ToInt32(metroTextBox4.Text);
            //MessageBox.Show(cl.ToString());
            clientADO.Inserer(cl);
            MessageBox.Show("client ajouter");
            metroGrid1.DataSource = ClientADO.Liste_Client();
            metroTextBox1.Clear();
            metroTextBox1.Focus();
            metroTextBox2.Clear();
            metroTextBox3.Clear();
            metroTextBox4.Clear();
            metroTextBox5.Clear();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            ClientADO clado = new ClientADO();
            Client cl = new Client();
            cl.Cin_Cl = Convert.ToInt32(metroTextBox1.Text);
            clado.Supprimer(cl.Cin_Cl);
            MessageBox.Show("client supprimer");
            metroGrid1.DataSource = ClientADO.Liste_Client();
            metroTextBox1.Clear();
            metroTextBox1.Focus();
            metroTextBox2.Clear();
            metroTextBox3.Clear();
            metroTextBox4.Clear();
            metroTextBox5.Clear();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Client cl = new Client();
            ClientADO clientADO = new ClientADO();
            cl.Cin_Cl = Convert.ToInt32(metroTextBox1.Text);
            cl.Nom_Cl = metroTextBox2.Text;
            cl.Pren_Cl = metroTextBox5.Text;
            cl.Ville_Cl = metroTextBox3.Text;
            cl.Tel_Cl = Convert.ToInt32(metroTextBox4.Text);
            //MessageBox.Show(cl.ToString());
            clientADO.Modifier(cl);
            MessageBox.Show("client modifier");
            metroGrid1.DataSource = ClientADO.Liste_Client();
            metroTextBox1.Clear();
            metroTextBox1.Focus();
            metroTextBox2.Clear();
            metroTextBox3.Clear();
            metroTextBox4.Clear();
            metroTextBox5.Clear();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Client cl = new Client();
            cl.Cin_Cl = Convert.ToInt32(metroTextBox1.Text);
            bool a;
            a = ClientADO.Existe_Client(cl.Cin_Cl);
            if (a == true)
            {
                MessageBox.Show("clien trouver");
                metroGrid1.DataSource = ClientADO.Liste_Client(cl.Cin_Cl);
            }
            else
                MessageBox.Show("client non trouver");
            metroTextBox1.Clear();
            metroTextBox1.Focus();
            metroTextBox2.Clear();
            metroTextBox3.Clear();
            metroTextBox4.Clear();
            metroTextBox5.Clear();
        }

        private void metroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = metroGrid1.Rows[e.RowIndex];
                metroTextBox1.Text = row.Cells["CIN"].Value.ToString();
                metroTextBox2.Text = row.Cells["Nom"].Value.ToString();
                metroTextBox5.Text = row.Cells["Prenom"].Value.ToString();
                metroTextBox3.Text = row.Cells["Ville"].Value.ToString();
                metroTextBox4.Text = row.Cells["Tel"].Value.ToString();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
