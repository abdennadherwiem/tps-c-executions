﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP5.METIER;
using TP5.ADO;
namespace TP5
{
    public partial class Modif_Produit : Form
    {
        public Modif_Produit()
        {
            InitializeComponent();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            Produit P = new Produit();
            ProduitADO ProduitADO = new ProduitADO();
            P.Ref_Prod = Convert.ToInt32(metroTextBox1.Text);
            P.Desig_Produit = metroTextBox2.Text;
            P.Categ_Produit = metroComboBox1.Text;
            P.Prix_Prod = float.Parse(metroTextBox3.Text);
            P.Qte_Produit = Convert.ToInt32(metroTextBox4.Text);
            //MessageBox.Show(cl.ToString());
            ProduitADO.Modifier(P);
            MessageBox.Show("Produit Modifier");
            metroTextBox1.Clear();
            metroTextBox1.Focus();
            metroTextBox2.Clear();
            metroTextBox3.Clear();
            metroTextBox4.Clear();
            metroComboBox1.Items.Clear();
            this.Close();
        }

        private void Modif_Produit_Load(object sender, EventArgs e)
        {
            //metroTextBox1.Text = Form_Produit.instance.mg1.Rows[0].ToString();
        }
    }
}
