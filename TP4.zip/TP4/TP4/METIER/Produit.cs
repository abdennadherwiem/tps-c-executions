﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP5.METIER
{
    public class Produit
    {
        public Int64 Ref_Prod { get; set; }
        public string Desig_Produit { get; set; }
        public string Categ_Produit { get; set; }
        public float Prix_Prod { get; set; }
        public Int64 Qte_Produit { get; set; }
    }
}
