﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP5.METIER
{
    class Commande
    {
        public Int64 num_C { get; set; }
        public Int64 cinC { get; set; }
        public DateTime DateC { get; set; }
    }
}
