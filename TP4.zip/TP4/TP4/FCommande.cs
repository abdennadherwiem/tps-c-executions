﻿using MetroFramework.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP5.ADO;
using TP5.METIER;

namespace TP5
{
    public partial class FCommande : MetroFramework.Forms.MetroForm
    {

        public static FCommande instance;
        public MetroGrid mg1;
        public FCommande()
        {
            InitializeComponent();
            mg1 = metroGrid1;
        }

        private void FCommande_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form_Produit f = new Form_Produit();
            f.Show();
            metroGrid1.Rows.Add(Form_Produit.instance.pp.Ref_Prod, Form_Produit.instance.pp.Prix_Prod, Form_Produit.instance.pp.Categ_Produit,metroTextBox7.Text,float.Parse(metroTextBox7.Text) * Form_Produit.instance.pp.Prix_Prod);
            metroTextBox8.Text = metroGrid1.Rows[0].Cells["Total"].Value.ToString();
        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
        public static DataTable Liste_Client()
        {
            DataTable dtcl = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select c.* , cd.Date_Cde from Client c , commande cd where c.CIN = cd.CIN", Connexion.cn);
            da.Fill(dtcl);
            return dtcl;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = true;
            Commande c = new Commande();
            CommandeADO CommandeADO = new CommandeADO();
            c.num_C = Convert.ToInt64(metroTextBox1.Text);
            c.cinC = Convert.ToInt64(metroTextBox2.Text);
            c.DateC = Convert.ToDateTime(metroTextBox9.Text);
            //MessageBox.Show(cl.ToString());
            CommandeADO.Inserer(c);
            MessageBox.Show("Commande ajouter");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Int32 n = Convert.ToInt32(metroTextBox1.Text);
            bool a;
            a = CommandeADO.Existe_Client(n);
            if (a == true)
            {
                MessageBox.Show("Commande trouver");
                button1.Enabled = true;
                groupBox2.Enabled = true;
                metroGrid2.DataSource = Liste_Client();
                metroTextBox2.Text = metroGrid2.Rows[0].Cells["CIN"].Value.ToString();
                metroTextBox3.Text = metroGrid2.Rows[0].Cells["Nom"].Value.ToString();
                metroTextBox4.Text = metroGrid2.Rows[0].Cells["Prenom"].Value.ToString();
                metroTextBox5.Text = metroGrid2.Rows[0].Cells["Ville"].Value.ToString();
                metroTextBox6.Text = metroGrid2.Rows[0].Cells["Tel"].Value.ToString();
                metroTextBox9.Text = metroGrid2.Rows[0].Cells["Date_Cde"].Value.ToString();
            }
            else
            {
                MessageBox.Show("Commande non trouver");
                button1.Enabled = true;
                button2.Enabled = true;
                groupBox2.Enabled=true;
                metroTextBox2.Clear();
                metroTextBox3.Clear();
                metroTextBox4.Clear();
                metroTextBox5.Clear();
                metroTextBox6.Clear();
                metroTextBox9.Focus();
            }
        }

        private void metroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
