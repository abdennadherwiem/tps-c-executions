﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ex2tp2
{
    public partial class Form1 : Form
    {
        Queue<int> QVolailles = new Queue<int>();//generique type
        Queue<int> QViandes = new Queue<int>();
        int Tick_Vol = 1;
        int Tick_Viand = 1;
        public Form1()
        {
            InitializeComponent();
        }
        private void Afficher_Volailles()
        {
            Lst_Volailles.Items.Clear();
            foreach (int ticket in QVolailles)
            {
                Lst_Volailles.Items.Add( ticket);
            }
        }

        private void Afficher_Viandes()
        {
            Lst_Viandes.Items.Clear();
            foreach (int ticket in QViandes)
            {
                Lst_Viandes.Items.Add( ticket);
            }
        }


        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void Btn_Tirer_Click(object sender, EventArgs e)
        {
            if (Rdb_Volailles.Checked)
            {
                QVolailles.Enqueue(Tick_Vol);
                Tick_Vol++;
                Afficher_Volailles();
            }
            else if (Rdb_Viandes.Checked)
            {
                QViandes.Enqueue(Tick_Viand);//spécifier element ajouter
                Tick_Viand++;
                Afficher_Viandes();
            }
        }

        private void Btn_Serv_Volail_Click(object sender, EventArgs e)
        {
            if (QVolailles.Count > 0)
            {
                QVolailles.Dequeue();
                Afficher_Volailles();
            }
            else
            {
                MessageBox.Show("La file d'attente Volailles est vide.");
            }
        }

        private void Btn_Serv_Viande_Click(object sender, EventArgs e)
        {
            if (QViandes.Count > 0)
            {
                QViandes.Dequeue();//non soecifier element car systematiquement suppression en tete
                Afficher_Viandes();
            }
            else
            {
                MessageBox.Show("La file d'attente Viandes est vide.");
            }
        }
    }
}
