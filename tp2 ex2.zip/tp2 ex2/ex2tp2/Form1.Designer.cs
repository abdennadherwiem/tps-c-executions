﻿namespace ex2tp2
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.Rdb_Volailles = new System.Windows.Forms.RadioButton();
            this.Rdb_Viandes = new System.Windows.Forms.RadioButton();
            this.Btn_Tirer = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Lst_Volailles = new System.Windows.Forms.ListBox();
            this.Btn_Serv_Volail = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Lst_Viandes = new System.Windows.Forms.ListBox();
            this.Btn_Serv_Viande = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Rdb_Volailles
            // 
            this.Rdb_Volailles.AutoSize = true;
            this.Rdb_Volailles.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Rdb_Volailles.Location = new System.Drawing.Point(26, 42);
            this.Rdb_Volailles.Name = "Rdb_Volailles";
            this.Rdb_Volailles.Size = new System.Drawing.Size(62, 17);
            this.Rdb_Volailles.TabIndex = 0;
            this.Rdb_Volailles.TabStop = true;
            this.Rdb_Volailles.Text = "volailles";
            this.Rdb_Volailles.UseVisualStyleBackColor = true;
            // 
            // Rdb_Viandes
            // 
            this.Rdb_Viandes.AutoSize = true;
            this.Rdb_Viandes.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Rdb_Viandes.Location = new System.Drawing.Point(135, 42);
            this.Rdb_Viandes.Name = "Rdb_Viandes";
            this.Rdb_Viandes.Size = new System.Drawing.Size(62, 17);
            this.Rdb_Viandes.TabIndex = 1;
            this.Rdb_Viandes.TabStop = true;
            this.Rdb_Viandes.Text = "viandes";
            this.Rdb_Viandes.UseVisualStyleBackColor = true;
            this.Rdb_Viandes.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // Btn_Tirer
            // 
            this.Btn_Tirer.Location = new System.Drawing.Point(360, 36);
            this.Btn_Tirer.Name = "Btn_Tirer";
            this.Btn_Tirer.Size = new System.Drawing.Size(109, 23);
            this.Btn_Tirer.TabIndex = 2;
            this.Btn_Tirer.Text = "tirer un ticket";
            this.Btn_Tirer.UseVisualStyleBackColor = true;
            this.Btn_Tirer.Click += new System.EventHandler(this.Btn_Tirer_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Rdb_Volailles);
            this.groupBox1.Controls.Add(this.Btn_Tirer);
            this.groupBox1.Controls.Add(this.Rdb_Viandes);
            this.groupBox1.Location = new System.Drawing.Point(115, 42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(547, 100);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Lst_Volailles);
            this.groupBox2.Controls.Add(this.Btn_Serv_Volail);
            this.groupBox2.Location = new System.Drawing.Point(182, 166);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 272);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "volailles";
            // 
            // Lst_Volailles
            // 
            this.Lst_Volailles.FormattingEnabled = true;
            this.Lst_Volailles.Location = new System.Drawing.Point(21, 77);
            this.Lst_Volailles.Name = "Lst_Volailles";
            this.Lst_Volailles.Size = new System.Drawing.Size(120, 95);
            this.Lst_Volailles.TabIndex = 1;
            // 
            // Btn_Serv_Volail
            // 
            this.Btn_Serv_Volail.Location = new System.Drawing.Point(41, 33);
            this.Btn_Serv_Volail.Name = "Btn_Serv_Volail";
            this.Btn_Serv_Volail.Size = new System.Drawing.Size(75, 23);
            this.Btn_Serv_Volail.TabIndex = 0;
            this.Btn_Serv_Volail.Text = "se servir";
            this.Btn_Serv_Volail.UseVisualStyleBackColor = true;
            this.Btn_Serv_Volail.Click += new System.EventHandler(this.Btn_Serv_Volail_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Lst_Viandes);
            this.groupBox3.Controls.Add(this.Btn_Serv_Viande);
            this.groupBox3.Location = new System.Drawing.Point(408, 166);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 263);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "viandes";
            // 
            // Lst_Viandes
            // 
            this.Lst_Viandes.FormattingEnabled = true;
            this.Lst_Viandes.Location = new System.Drawing.Point(32, 88);
            this.Lst_Viandes.Name = "Lst_Viandes";
            this.Lst_Viandes.Size = new System.Drawing.Size(120, 95);
            this.Lst_Viandes.TabIndex = 1;
            // 
            // Btn_Serv_Viande
            // 
            this.Btn_Serv_Viande.Location = new System.Drawing.Point(53, 43);
            this.Btn_Serv_Viande.Name = "Btn_Serv_Viande";
            this.Btn_Serv_Viande.Size = new System.Drawing.Size(75, 23);
            this.Btn_Serv_Viande.TabIndex = 0;
            this.Btn_Serv_Viande.Text = "se servir";
            this.Btn_Serv_Viande.UseVisualStyleBackColor = true;
            this.Btn_Serv_Viande.Click += new System.EventHandler(this.Btn_Serv_Viande_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton Rdb_Volailles;
        private System.Windows.Forms.RadioButton Rdb_Viandes;
        private System.Windows.Forms.Button Btn_Tirer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox Lst_Volailles;
        private System.Windows.Forms.Button Btn_Serv_Volail;
        private System.Windows.Forms.ListBox Lst_Viandes;
        private System.Windows.Forms.Button Btn_Serv_Viande;
    }
}

